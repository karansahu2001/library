<?php
include("db.php");

if (isset($_POST['action']) && $_POST['action'] == "search") {
    $id = $_POST['id'];
    $sql = "SELECT * FROM `bookcopies` WHERE `bookId` = '$id'";
    $res = mysqli_query($conn, $sql);
    if (mysqli_num_rows($res) > 0) {
        $row = mysqli_fetch_assoc($res);
        $bookCopyId = $row['id'];
        if ($row["issueStatus"] == "AVAILABLE") {
            $sql = "SELECT * FROM `BookAuthors` WHERE `bookId` = '$id'";
            $res = mysqli_query($conn, $sql);
            $row = mysqli_fetch_assoc($res);
            $authorId = $row['authorId'];
            $sql_author = "SELECT * FROM `Authors` WHERE `id` = '$authorId'";
            $sql_book = "SELECT * FROM `Books` WHERE `id` = '$id'";

            $res_author = mysqli_query($conn, $sql_author);
            $res_book = mysqli_query($conn, $sql_book);

            $row_author = mysqli_fetch_assoc($res_author);
            $row_book = mysqli_fetch_assoc($res_book);

            $publisherId = $row_book['publisherId'];
            $publisher = "";
            if ($publisherId != null) {
                $sql_publisher = "SELECT * FROM `publishers` WHERE `id` = '$publisherId'";
                $res_publisher = mysqli_query($conn, $sql_publisher);
                $row_publisher = mysqli_fetch_assoc($res_publisher);
                $publisher = $row_publisher['name'];
            }

?>
<table class="table">
    <input type="hidden" value="okey" id="abc">
    <tbody>
        <tr>
            <td>Book Name</td>
            <td>
                <?php echo $row_book['title'] ?>
            </td>
        </tr>
        <tr>
            <td>Author</td>
            <td>
                <?php echo $row_author['lastName'] ?>
            </td>
        </tr>
        <tr>
            <td>BookCopy Id</td>
            <td>
                <?php echo $bookCopyId; ?>
            </td>
        </tr>
        <tr>
            <td>Edition</td>
            <td>
                <?php echo $row_book['edition'] ?>
            </td>
        </tr>
        <tr>
            <td>Publisher Name</td>
            <td>
                <?php echo $publisher; ?>
            </td>
        </tr>

    </tbody>
</table>

<?php
        } else {
            echo "Book is already issue";
        }
    } else {
        echo "Book is not found";
    }
}

if (isset($_POST['action']) && $_POST['action'] == "issue") {
    $bookId = $_POST['bookId'];
    $userId = $_POST['userId'];
    if ($userId != "") {
        $sql = "SELECT * FROM `users` WHERE `phone` = '$userId'";
        $res = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($res);


        if (mysqli_num_rows($res) > 0) {
            $sql_bookcopies = "SELECT * FROM `bookcopies` WHERE `bookId` = '$bookId'";
            $res_bookcopies = mysqli_query($conn, $sql_bookcopies);
            $row_bookcopies = mysqli_fetch_assoc($res_bookcopies);

            $sql_books = "SELECT * FROM `books` WHERE `id` = '$bookId'";
            $res_books = mysqli_query($conn, $sql_books);
            $row_books = mysqli_fetch_assoc($res_books);

            $id = $row['id'];
            $userFullName = $row['firstName'] . " " . $row['lastName'];
            $bookCopyId = $row_bookcopies['id'];
            $bookTitle = $row_books['title'];
            $bookSN = $row_books['bookSN'];
            $issueDate = date("Y-m-d");
            $expiryDate = date("Y-m-d", strtotime("+1 month"));

            date_default_timezone_set("Asia/Kolkata");
            $updateDateTime = date('Y-m-d H:i:s');

            $sql = "INSERT INTO issuelogs(userId,userFullName,bookId,bookCopyId,bookTitle,bookSN,issueDate,expiryDate,updateDateTime) VALUES('$id','$userFullName','$bookId','$bookCopyId','$bookTitle','$bookSN','$issueDate','$expiryDate','$updateDateTime')";
            mysqli_query($conn, $sql);

            $sql1 = "UPDATE `bookcopies` SET `issueStatus` = 'ISSUED' WHERE `bookId` = '$bookId'";
            mysqli_query($conn, $sql1);

            echo false;

        } else {
            echo true;
        }
    } else {
        echo true;
    }


}