<?php
include("db.php");

if (isset($_POST['action']) && $_POST['action'] == "search") {
    $bookId = $_POST['bookId'];
    $sql = "SELECT * FROM `bookcopies` WHERE `bookId` = '$bookId' AND `issueStatus`= 'ISSUED'";
    $res = mysqli_query($conn, $sql);
    if (mysqli_num_rows($res) > 0) {
        $sql = "SELECT * FROM `issuelogs` WHERE `bookId` = '$bookId'";
        $res = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($res);
?>
<table class="table">
    <tbody>
        <input type="hidden" value="okey" id="asd">

        <tr>
            <td>Book Name</td>
            <td>
                <?php echo $row['bookTitle'] ?>
            </td>
        </tr>
        <tr>
            <td>User Id</td>
            <td>
                <?php echo $row['userId'] ?>
            </td>
        </tr>
        <tr>
            <td>User Name</td>
            <td>
                <?php echo $row['userFullName'] ?>
            </td>
        </tr>
        <tr>
            <td>Issue Data</td>
            <td>
                <?php echo $row['issueDate'] ?>
            </td>
        </tr>
        <tr>
            <td>Expiry Data</td>
            <td>
                <?php echo $row['expiryDate'] ?>
            </td>
        </tr>

    </tbody>
</table>
<?php
    }else{
        echo "Book not found";
    }

}

if (isset($_POST['action']) && $_POST['action'] == "return") {
    $bookId = $_POST['bookId'];
    $sql = "SELECT * FROM `bookcopies` WHERE `bookId` = '$bookId' AND `issueStatus`= 'ISSUED'";
    $res = mysqli_query($conn, $sql);
    if (mysqli_num_rows($res) > 0) {
        $date = date("Y-m-d");
        $sql = "UPDATE `bookcopies` SET `issueStatus` = 'AVAILABLE' WHERE `bookId` = '$bookId'";
        mysqli_query($conn, $sql);
        
        date_default_timezone_set("Asia/Kolkata");
        $updateDateTime = date('Y-m-d H:i:s');

        $sql = "UPDATE `issuelogs` SET `isIssueDeleted` = 1, `returnDate`= '$date', `updateDateTime`='$updateDateTime'   WHERE `bookId` = '$bookId'";
        mysqli_query($conn, $sql);

        echo true;
    }else{
        echo false;
    }
}
