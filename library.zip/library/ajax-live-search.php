<?php

include("db.php");

if (isset($_POST['query'])) {
    $query = "SELECT * FROM `Books` WHERE `id` LIKE '{$_POST['query']}%' LIMIT 100";
    $result = mysqli_query($conn, $query);
  if (mysqli_num_rows($result) > 0) {
      while ($res = mysqli_fetch_array($result)) {
      echo $res['title']. "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#".$res['id']. "<br/>";
    }
  } else {
    echo "
    <div class='alert alert-danger mt-3 text-center' role='alert'>
        Book not found
    </div>
    ";
  }
}